These sounds were found [here](http://www.teenageengineering.com/library/op-1/sounds),
with the name "DJTW - AceFR-1". Thank you, Thomas White and Teenage Engineering.
